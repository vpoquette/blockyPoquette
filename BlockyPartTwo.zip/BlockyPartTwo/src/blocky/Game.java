package blocky;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Game
{
    //=== Public Attributes ===
    //root:
    //    The Blocky board on which this game will be played.
    private Block root;
    
    //highlightedBlock:
    //    The block the user has selected.  This will be colored specially when rendered.
    private Block highlightedBlock;
    
    public Game()
    {
        //root = createTestBoard();
        root = new Block();
        createRandomChildren(root);
        highlightedBlock = null;
    }
    
    public void createRandomChildren(Block parent)
    { // Thanks Kris
        List<Block> blocks = new ArrayList<>();
        
        for(int index = 0; index < 4; index++){
            Block child = new Block();
            child.setLevel(parent.getLevel() + 1);
            child.setSize(parent.getSize() / 2); // 1/2 or 1/4
            child.setParent(parent);
            int randomNum = ThreadLocalRandom.current().nextInt(1, 4 + 1);
            switch (randomNum) {
                case 1 -> child.setColor(Block.DAFFODIL_DELIGHT);
                case 2 -> child.setColor(Block.PACIFIC_POINT);
                case 3 -> child.setColor(Block.OLD_OLIVE);
                case 4 -> child.setColor(Block.REAL_RED);
                default -> {child.setColor(Block.MELON_MAMBO);}
            }
            blocks.add(child);
        }
        parent.setChildren(blocks);
        
        for(int outdex = 0; outdex < blocks.size(); outdex++){
            Block child = blocks.get(outdex);
            if (child.getLevel() != Block.MAX_DEPTH){ // if there's room
                if (Math.random() < Math.exp(-0.25 * child.getLevel())){ // and if random number generate nicely
                    for(int index = 0; index < 4; index++){
                        createRandomChildren(child); // 4 children it is! Everyone gets quadruplets
                    }
                }
            }
        }
    }
    
    public Block createTestBoard()
    {
        Block root = new Block();
        root.setSize(Block.MAX_SIZE);
        
        List<Block> rootChildren = new ArrayList<>();
        rootChildren.add(new Block(Block.DAFFODIL_DELIGHT, 1, 320, root));
        rootChildren.add(new Block(Block.OLD_OLIVE, 1, 320, root));
        rootChildren.add(new Block(Block.PACIFIC_POINT, 1, 320, root));
        rootChildren.add(new Block(Block.REAL_RED, 1, 320, root));
        
        root.setChildren(rootChildren);
        Block child = root.getChildren().get(0);
        
        rootChildren = new ArrayList<>();
        rootChildren.add(new Block(Block.DAFFODIL_DELIGHT, 2, 160, child));
        rootChildren.add(new Block(Block.OLD_OLIVE, 2, 160, child));
        rootChildren.add(new Block(Block.PACIFIC_POINT, 2, 160, child));
        rootChildren.add(new Block(Block.REAL_RED, 2, 160, child));
        
        child.setChildren(rootChildren);
        
        return root;
    }

    public Block getRoot()
    {
        return root;
    }

    public Block getHighlightedBlock()
    {
        return highlightedBlock;
    }

    public void setRoot(Block root)
    {
        this.root = root;
    }

    public void setHighlightedBlock(Block highlightedBlock)
    {
        this.highlightedBlock = highlightedBlock;
    }
}
